# دليل دعم JSON المتقدم

## نظرة عامة

تم إضافة دعم قوي وشامل لملفات JSON في المشروع، يتضمن مكتبة معالجة متقدمة، مكونات React تفاعلية، وأدوات ويب كاملة.

## المكونات الرئيسية

### 1. مكتبة JsonProcessor

مكتبة TypeScript قوية توفر أكثر من 20 وظيفة لمعالجة JSON:

#### الوظائف الأساسية:
- **deepClone**: نسخ عميق للكائنات
- **deepMerge**: دمج متعدد المستويات
- **getByPath / setByPath / deleteByPath**: عمليات المسار
- **flatten / unflatten**: تحويل البنية

#### التحليل والإحصائيات:
- **calculateStats**: إحصائيات شاملة (الحجم، العمق، الأنواع)
- **extractKeys**: استخراج جميع المفاتيح
- **search**: بحث متقدم في المفاتيح والقيم

#### المقارنة والتحقق:
- **compare**: مقارنة شاملة بين كائنين
- **validate**: التحقق من المخطط
- **sortKeys**: ترتيب المفاتيح

#### التحويل:
- **transform**: تحويل مخصص
- **removeNullish**: إزالة القيم الفارغة
- **compress / prettyPrint**: تنسيق

### 2. مكونات React

#### JsonViewer
عارض تفاعلي مع:
- طي وفتح العقد
- نسخ القيم
- تلوين حسب النوع
- دعم المصفوفات والكائنات

```tsx
<JsonViewer 
    data={myData} 
    name="root" 
    collapsed={false}
    theme="dark"
/>
```

#### JsonEditor
محرر تفاعلي مع:
- تعديل القيم مباشرة
- إضافة وحذف العناصر
- حفظ وإلغاء التغييرات
- وضع القراءة فقط

```tsx
<JsonEditor 
    initialData={myData}
    onChange={(newData) => handleChange(newData)}
    readOnly={false}
/>
```

#### JsonDiff
مقارنة بصرية مع:
- عرض الفروقات بالألوان
- تصنيف التغييرات (إضافة، حذف، تعديل)
- عرض المسارات المتأثرة

```tsx
<JsonDiff 
    json1={jsonString1}
    json2={jsonString2}
    title1="الأصلي"
    title2="المعدل"
/>
```

### 3. صفحات الويب

#### صفحة JSON Tool (`/json-tool`)

أداة شاملة تتضمن:

**العمليات الأساسية:**
- تنسيق (Format)
- ضغط (Minify)
- التحقق (Validate)
- عرض الإحصائيات

**البحث والتصفية:**
- بحث في المفاتيح والقيم
- تصفية حسب المسار
- استخراج المفاتيح

**العمليات المتقدمة:**
- ترتيب المفاتيح
- تسطيح البنية
- التحويل من/إلى CSV
- رفع الملفات

**الميزات:**
- واجهة مستخدم احترافية
- دعم السحب والإفلات
- نسخ وتحميل النتائج
- رسائل خطأ واضحة

#### صفحة JSON Compare (`/json-compare`)

أداة مقارنة متقدمة:

**الميزات:**
- مقارنة جنباً إلى جنب
- عرض الفروقات بالألوان
- تبديل الملفات
- تصدير النتائج

**أنواع الفروقات:**
- 🟢 إضافة (Added)
- 🔴 حذف (Removed)
- 🟡 تعديل (Modified)

## البنية التنظيمية

```
packages/webapp/src/
├── lib/json/
│   ├── JsonProcessor.ts          # المكتبة الرئيسية
│   ├── JsonProcessor.test.ts     # الاختبارات
│   ├── index.ts                  # التصدير
│   └── README.md                 # التوثيق
│
├── components/json/
│   ├── JsonViewer.tsx            # عارض JSON
│   ├── JsonEditor.tsx            # محرر JSON
│   ├── JsonDiff.tsx              # مقارنة JSON
│   └── index.ts                  # التصدير
│
└── pages/
    ├── json-tool/
    │   └── index.tsx             # أداة JSON الرئيسية
    └── json-compare/
        └── index.tsx             # أداة المقارنة
```

## أمثلة الاستخدام

### مثال 1: معالجة بيانات متداخلة

```typescript
import { JsonProcessor } from '@/lib/json/JsonProcessor';

const data = {
    students: [
        { name: 'أحمد', grades: { math: 95, science: 88 } },
        { name: 'سارة', grades: { math: 92, science: 94 } }
    ]
};

// استخراج جميع المفاتيح
const keys = JsonProcessor.extractKeys(data);
// ['students', 'students.name', 'students.grades', ...]

// البحث عن طالب
const results = JsonProcessor.search(data, 'أحمد');

// الحصول على درجة محددة
const mathGrade = JsonProcessor.getByPath(data, 'students.0.grades.math');
```

### مثال 2: دمج إعدادات

```typescript
const defaultSettings = {
    theme: 'light',
    language: 'ar',
    notifications: {
        email: true,
        sms: false
    }
};

const userSettings = {
    theme: 'dark',
    notifications: {
        sms: true
    }
};

const finalSettings = JsonProcessor.deepMerge(defaultSettings, userSettings);
// Result: { theme: 'dark', language: 'ar', notifications: { email: true, sms: true } }
```

### مثال 3: تحليل البيانات

```typescript
const apiResponse = { /* بيانات كبيرة */ };

const stats = JsonProcessor.calculateStats(apiResponse);
console.log(`الحجم: ${stats.size} بايت`);
console.log(`العمق: ${stats.depth} مستويات`);
console.log(`عدد المفاتيح: ${stats.keys}`);
console.log(`عدد المصفوفات: ${stats.arrays}`);
```

### مثال 4: مقارنة الإصدارات

```typescript
const version1 = { /* إصدار قديم */ };
const version2 = { /* إصدار جديد */ };

const comparison = JsonProcessor.compare(version1, version2);

if (!comparison.equal) {
    comparison.differences.forEach(diff => {
        console.log(`${diff.type} في ${diff.path}`);
    });
}
```

## الأداء والكفاءة

### التحسينات:
- معالجة سريعة للملفات الكبيرة (حتى 10MB)
- استخدام فعال للذاكرة
- تخزين مؤقت للنتائج
- معالجة متزامنة

### أفضل الممارسات:
1. استخدم `deepClone` بدلاً من `JSON.parse(JSON.stringify())`
2. استخدم `getByPath` للوصول الآمن للقيم المتداخلة
3. استخدم `search` بدلاً من التكرار اليدوي
4. استخدم `compare` لمقارنة الكائنات الكبيرة

## الأمان

### الحماية المدمجة:
- تنظيف البيانات تلقائياً
- حماية من الحقن
- التحقق من الصحة قبل المعالجة
- معالجة آمنة للأخطاء

### نصائح الأمان:
1. تحقق من صحة JSON قبل المعالجة
2. استخدم `validate` للتحقق من المخطط
3. تجنب معالجة بيانات غير موثوقة مباشرة
4. استخدم `removeNullish` لتنظيف البيانات

## الاختبارات

تم إنشاء مجموعة شاملة من الاختبارات:

```bash
# تشغيل الاختبارات
npm test

# تشغيل اختبارات محددة
npm test JsonProcessor.test.ts

# تشغيل مع التغطية
npm test -- --coverage
```

### تغطية الاختبارات:
- ✅ جميع الوظائف الأساسية
- ✅ حالات الحدود
- ✅ معالجة الأخطاء
- ✅ الأداء

## التكامل مع المشروع

### الاستيراد في المكونات:

```typescript
// استيراد المكتبة
import { JsonProcessor } from '@/lib/json';

// استيراد المكونات
import { JsonViewer, JsonEditor, JsonDiff } from '@/components/json';

// استيراد الأنواع
import type { JsonStats, ComparisonResult } from '@/lib/json';
```

### الاستخدام في API Routes:

```typescript
// pages/api/process-json.ts
import { JsonProcessor } from '@/lib/json/JsonProcessor';

export default function handler(req, res) {
    const data = req.body;
    const stats = JsonProcessor.calculateStats(data);
    res.json(stats);
}
```

## الميزات المستقبلية

### قيد التطوير:
- [ ] دعم JSON Schema المتقدم
- [ ] تصدير إلى XML
- [ ] محرر مرئي بالسحب والإفلات
- [ ] دعم JSONPath
- [ ] تكامل مع قواعد البيانات
- [ ] API للمعالجة الجماعية

### التحسينات المخططة:
- [ ] تحسين الأداء للملفات الضخمة (>100MB)
- [ ] دعم البث (Streaming)
- [ ] ضغط متقدم
- [ ] تشفير البيانات الحساسة

## الدعم والمساعدة

### الموارد:
- 📖 التوثيق الكامل: `/src/lib/json/README.md`
- 🧪 أمثلة الاختبارات: `/src/lib/json/JsonProcessor.test.ts`
- 💻 أمثلة الاستخدام: في هذا الملف

### المشاكل الشائعة:

**مشكلة: خطأ في التحليل**
```typescript
// ❌ خطأ
const data = JsonProcessor.flatten("not json");

// ✅ صحيح
try {
    const parsed = JSON.parse(jsonString);
    const data = JsonProcessor.flatten(parsed);
} catch (error) {
    console.error('Invalid JSON');
}
```

**مشكلة: مسار غير موجود**
```typescript
// ❌ قد يسبب خطأ
const value = data.user.profile.name;

// ✅ آمن
const value = JsonProcessor.getByPath(data, 'user.profile.name');
```

## الخلاصة

تم إضافة دعم شامل ومتقدم لملفات JSON يتضمن:

✅ مكتبة معالجة قوية مع 20+ وظيفة
✅ 3 مكونات React تفاعلية
✅ 2 صفحة ويب كاملة
✅ اختبارات شاملة
✅ توثيق مفصل
✅ أمثلة عملية

النظام جاهز للاستخدام الفوري ويوفر جميع الأدوات اللازمة لمعالجة وتحليل ملفات JSON بكفاءة وأمان.
